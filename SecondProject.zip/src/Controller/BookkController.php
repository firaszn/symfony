<?php

namespace App\Controller;

use App\Entity\Bookk;
use App\Form\BookkType;
use App\Repository\BookkRepository;
use App\Repository\BookRepository;
use Doctrine\Persistence\ManagerRegistry;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\Form\Extension\Core\Type\SubmitType;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;

class BookkController extends AbstractController
{
    #[Route('/listbook/', name: 'list_book')]
    public function list(BookkRepository $bookkRepository): Response
    { 
        $books = $bookkRepository->findAll();

        return $this->render('bookk/list.html.twig', [
            'books' => $books,
        ]);
    }



    
        #[Route('/bookk/add', name: 'addbookk')]
        public function addbook(ManagerRegistry $doctrine, Request $request): Response
    {
        $bookk = new Bookk();

        $form = $this->createForm(BookkType::class, $bookk);
        $form->add('Ajouter', SubmitType::class);

        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
            $em = $doctrine->getManager();

            $author = $bookk->getAuthor();

            if ($author) {
                $author->setNbBooks($author->getNbBooks() + 1);
            }

            $em->persist($bookk);
            $em->flush();

            return $this->redirectToRoute('list_book');
        }

        return $this->render('bookk/addbookk.html.twig', [
            'formB' => $form->createView(),
        ]);
    }
    #[Route('/published-books', name: 'published_books')]
public function publishedBooks(BookkRepository $bookkRepository): Response
{
    $publishedBooks = $bookkRepository->findBy(['published' => true]);
    $unpublishedBooks = $bookkRepository->findBy(['published' => false]);

    $publishedCount = count($publishedBooks);
    $unpublishedCount = count($unpublishedBooks);


    return $this->render('bookk/published_books.html.twig', [
        'publishedBooks' => $publishedBooks,
        'unpublishedBooks' => $unpublishedBooks,
        'publishedCount' => $publishedCount,
        'unpublishedCount' => $unpublishedCount,
    ]);
}
#[Route('/bookk/edit/{ref}', name: 'edit_book')]
public function editBook(string $ref, ManagerRegistry $doctrine, Request $request, BookkRepository $bookkRepository): Response
{
    $bookk = $bookkRepository->findOneBy(['ref' => $ref]);
    if (!$bookk) {
        throw $this->createNotFoundException('Book not found');
    }

    $form = $this->createForm(BookkType::class, $bookk);
    $form->add('Modifier', SubmitType::class);

    $form->handleRequest($request);

    if ($form->isSubmitted() && $form->isValid()) {
        $em = $doctrine->getManager();
        $em->flush();

        return $this->redirectToRoute('list_book');
    }

    return $this->render('bookk/editbookk.html.twig', [
        'formB' => $form->createView(),
    ]);
}
#[Route('/bookk/delete/{ref}', name: 'delete_book')]
public function deleteBook(string $ref, ManagerRegistry $doctrine, BookkRepository $bookkRepository): Response
{
    $em = $doctrine->getManager();
    $bookk = $bookkRepository->findOneBy(['ref' => $ref]);

    if (!$bookk) {
        throw $this->createNotFoundException('Book not found');
    }

    $em->remove($bookk);
    $em->flush();

    return $this->redirectToRoute('published_books');
}

#[Route('/bookk/showBook{ref}', name: 'show_book')]
public function showBook($ref ,  BookkRepository $bookkRepository ): Response
{ 

    $bookk = $bookkRepository->findOneBy(['ref' => $ref]);
    return $this->render('bookk/detail.html.twig', ['book' => $bookk
    ]);
}


}
